class Cliente:
    def __init__(self, nombre, apellido, edad, dni, telefono):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.dni = dni
        self.telefono = telefono
        print(f"Se creo el ususario {nombre} {apellido}")

    def __str__(self):
        return f"El cliente se llama {self.nombre} {self.apellido}, su dni es {self.dni} y su telefono {self.telefono}"

    def comprar (self, producto, ubicacion):
        print(f"{self.nombre} compro un {producto} en {ubicacion}")

    def cambiar_telefono(self, nuevo_telefono):
        print(f"Se cambio el telefono {self.telefono} por el {nuevo_telefono}")
        self.telefono = nuevo_telefono
        