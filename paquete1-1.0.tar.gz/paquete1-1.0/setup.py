from setuptools import setup

setup(
    name = "paquete1",
    version = "1.0",
    description = "Paquete entrega coder",
    author = "Gonzalo Silva",
    author_email = "gonza_219@hotmail.com",
    packages = ["paquete1"]

)